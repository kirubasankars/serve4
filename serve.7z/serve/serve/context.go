package serve

import (
	"fmt"
	"strconv"
	"strings"
)

// Context for serve
type Context struct {
	server      *Server
	namespace   *Namespace
	application *Application
	module      *Module

	url  string
	path string
}

// Server context server
func (ctx *Context) Server() *Server {
	return ctx.server
}

// NameSpace context
func (ctx *Context) NameSpace() *Namespace {
	return ctx.namespace
}

// Application context
func (ctx *Context) Application() *Application {
	return ctx.application
}

// Module context
func (ctx *Context) Module() *Module {
	return ctx.module
}

// GetConfig get config data from module/app/namespace/server
func (ctx *Context) GetConfig(key string) interface{} {

	if module := ctx.module; module != nil {
		if value := module.GetConfig(key); value != nil {
			return value
		}
	}

	if app := ctx.application; app != nil {
		if value := app.GetConfig(key); value != nil {
			return value
		}
	}

	if ns := ctx.namespace; ns != nil {
		if value := ns.GetConfig(key); value != nil {
			return value
		}
	}

	if server := ctx.server; server != nil {
		if value := server.GetConfig(key); value != nil {
			return value
		}
	}

	return nil
}

// NewContext for create new context
func newContext(server *Server, url string) *Context {

	url = strings.TrimSpace(url)
	if url == "" {
		return nil
	}

	system := server.System
	namespace, namespacePath, app, appPath, module, modulePath, path := system.GetPath(server, url)

	ctx := new(Context)
	ctx.url = url
	ctx.server = server
	ctx.path = path

	fmt.Printf("\n namespace : %s, path : %s \n app : %s, path : %s \n module : %s, path : %s \n", namespace, namespacePath, app, appPath, module, modulePath)

	getNamespace(ctx, namespace, namespacePath)
	getApplication(ctx, app, appPath)
	getModule(ctx, module, modulePath)

	return ctx
}

func getNamespace(ctx *Context, name string, path string) {
	if name == "" {
		return
	}
	server := ctx.server
	namespace, present := server.namespaces[name]
	if present == false {
		namespace = server.System.GetNamespace(ctx, name, path)
		namespace.apps = make(map[string]*Application)
		namespace.modules = make(map[string]*Module)
		server.namespaces[name] = namespace
	}
	ctx.namespace = namespace
}

func getApplication(ctx *Context, name string, path string) {
	if name == "" {
		return
	}
	server := ctx.server
	namespace := ctx.namespace
	app, present := namespace.apps[name]
	if present == false {
		app = server.System.GetApplication(ctx, name, path)
		namespace.apps[name] = app
	}
	ctx.application = app
}

func getModule(ctx *Context, name string, path string) {
	server := ctx.server
	system := server.System

	if name == "" {
		if ctx.GetConfig("modules.@0") != nil {
			name, _ = ctx.GetConfig("modules.@0").(string)
			name, path = system.GetModulePath(server, ctx.namespace.Name, name)
		}
	} else {
		if ctx.GetConfig("modules") != nil {
			l, _ := ctx.GetConfig("modules.$length").(int)

			for i := 0; i < l; i++ {
				t, _ := ctx.GetConfig("modules.@" + strconv.Itoa(i)).(string)
				if t == name {
					name, path = system.GetModulePath(server, ctx.namespace.Name, name)
				}
			}
		}
	}

	if name == "" {
		name, path = system.GetModulePath(server, ctx.namespace.Name, "home")
	}

	if namespace, present := server.namespaces[ctx.namespace.Name]; present == true {
		module := namespace.modules[name]
		if module == nil {
			module = system.GetModule(ctx, name, path)
			module.server = server
			module.build()
			namespace.modules[name] = module
		}

		ctx.module = module
	}
}
