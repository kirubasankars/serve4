package serve

import (
	"fmt"
	"net/http"

	"github.com/kirubasankars/serve/metal"
)

// HTTPHandler its handler for serve
type HTTPHandler func(ctx Context, w http.ResponseWriter, r *http.Request)

// Module for serve
type Module struct {
	Name   string
	Path   string
	config *metal.Metal

	AppEnabled  bool
	AuthEnabled bool
	Handlers    map[string]HTTPHandler

	mux    *http.ServeMux
	server *Server
}

// GetConfig get config from module
func (module *Module) GetConfig(key string) interface{} {
	if module.config == nil {
		return nil
	}
	return module.GetConfig(key)
}

func (module *Module) build() {
	//fmt.Println("dasd")
	server := module.server
	if provider, p := server.moduleProvider["."]; p {
		provider.Build(*module)
	}

	if provider, p := server.moduleProvider[module.Name]; p {
		provider.Build(*module)
	}

	mux := module.mux

	// mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
	// 	http.Redirect(w, r, r.URL.Path+"/"+module.Name+"/", 301)
	// })

	for pattern, handler := range module.Handlers {
		if pattern != "" {
			var mh = new(moduleHandler)
			mh.handler = handler
			mh.module = module
			uri := "/" + module.Name + pattern

			fmt.Println("build", uri)
			mux.Handle(uri, mh)
		}
	}

	mux.HandleFunc("/"+module.Name, func(w http.ResponseWriter, r *http.Request) {
		http.Redirect(w, r, r.URL.Path+"/", 301)
	})
}

type moduleHandler struct {
	handler HTTPHandler
	module  *Module
}

func (mh *moduleHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	//ctx := newContext(mh.module.server, r.URL.Path)
	//fmt.Println(uri)
	mh.handler(*contexts[r], w, r)
}

// NewModule create module
func NewModule(name string, path string, config *metal.Metal, server *Server) *Module {
	module := new(Module)
	module.Name = name
	module.Path = path
	module.config = config
	module.server = server

	module.Handlers = make(map[string]HTTPHandler)
	module.mux = http.NewServeMux()

	return module
}
