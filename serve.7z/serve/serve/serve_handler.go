package serve

import "net/http"

type serveHandler struct{}

var contexts map[*http.Request]*Context

func init() {
	contexts = make(map[*http.Request]*Context)
}

func (serveHandler *serveHandler) ServeHTTP(ctx Context, w http.ResponseWriter, r *http.Request) {
	if ctx.module == nil {
		http.NotFound(w, r)
		return
	}
	if ctx.module.Name == "_refresh" {
		delete(ctx.server.namespaces, ctx.namespace.Name)
		return
	}
	serveHandler.Serve(ctx, w, r)
}

func (serveHandler *serveHandler) Serve(ctx Context, w http.ResponseWriter, r *http.Request) {
	contexts[r] = &ctx
	//fmt.Println("serve", "/"+ctx.module.Name+ctx.path)
	fakeR, _ := http.NewRequest(r.Method, "/"+ctx.module.Name+ctx.path, nil)
	handler, _ := ctx.module.mux.Handler(fakeR)
	fakeR.URL.Path = r.URL.Path
	handler.ServeHTTP(w, r)
	delete(contexts, r)
}
