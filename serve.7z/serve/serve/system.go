package serve

import (
	"github.com/kirubasankars/serve/metal"
)

//System inferface for driver
type System interface {
	GetPath(server *Server, url string) (string, string, string, string, string, string, string)
	GetModulePath(server *Server, namespace string, name string) (module string, modulePath string)

	GetNamespace(ctx *Context, name string, path string) *Namespace
	GetApplication(ctx *Context, name string, path string) *Application
	GetModule(ctx *Context, name string, path string) *Module

	GetConfig(path string) *metal.Metal
}
