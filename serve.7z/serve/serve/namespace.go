package serve

import "github.com/kirubasankars/serve/metal"

//Namespace sturct
type Namespace struct {
	Name   string
	Path   string
	config *metal.Metal

	modules map[string]*Module
	apps    map[string]*Application

	server *Server
}

// GetConfig get config from namespace
func (ns *Namespace) GetConfig(key string) interface{} {
	if ns.config == nil {
		return nil
	}
	return ns.GetConfig(key)
}

// NewNamespace create namespace
func NewNamespace(name string, path string, config *metal.Metal, server *Server) *Namespace {
	namespace := new(Namespace)
	namespace.Name = name
	namespace.Path = path
	namespace.config = config

	namespace.apps = make(map[string]*Application)
	namespace.modules = make(map[string]*Module)
	namespace.server = server

	return namespace
}
