package driver

import (
	"io/ioutil"
	"os"
	"path/filepath"
	"strings"

	"github.com/kirubasankars/serve/metal"
	"github.com/kirubasankars/serve/serve"
)

// FileSystem driver
type FileSystem struct {
	stat      func(filename string) bool
	getConfig func(path string) *metal.Metal
}

// GetPath for path information
func (fs *FileSystem) GetPath(server *serve.Server, url string) (namespace *serve.Namespace, application *serve.Application, module *serve.Module, uri string) {
	parts := strings.Split(url, "/")
	length := 0
	currentIdx := 0

	path := ""

	if parts[currentIdx] == "" {
		length++
		currentIdx++
	}

	if parts[currentIdx] == "apps" || parts[currentIdx] == "modules" {
		length = 0
		return
	}

	ns := parts[currentIdx]
	nsPath := ns
	path = filepath.Join(server.Path(), nsPath)
	if ns != "" && fs.stat(path) {
		length += len(ns) + 1
		currentIdx++
	} else {
		ns = "."
		nsPath = "."
	}

	app := parts[currentIdx]
	appPath := filepath.Join(ns, "apps", app)
	path = filepath.Join(server.Path(), appPath)
	if app != "" && fs.stat(path) {
		length += len(app)
		currentIdx++
	} else {
		app = ""
		appPath = ""
		length--
	}

	// if len(parts)-1 < currentIdx {
	// 	return
	// }

	m := parts[currentIdx]
	length += len(m) + 1

	m, mPath := fs.GetModulePath(server, ns, m)
	if m == "" {
		length -= len(m) + 1
	}

	namespace = new(serve.Namespace)
	namespace.Name = ns
	namespace.Path = nsPath

	application = new(serve.Application)
	application.Name = app
	application.Path = appPath

	module = new(serve.Module)
	module.Name = m
	module.Path = mPath

	uri = url[length:]

	return
}

// GetModulePath dd
func (fs *FileSystem) GetModulePath(server *serve.Server, namespace string, name string) (module string, modulePath string) {
	module = name
	modulePath = filepath.Join(namespace, "modules", module)
	path := filepath.Join(server.Path(), modulePath)
	if module != "" && fs.stat(path) {
		return
	}

	modulePath = filepath.Join("modules", module)
	path = filepath.Join(server.Path(), modulePath)
	//fmt.Println(path)
	if module == "" || fs.stat(path) == false {
		module = ""
		modulePath = ""
	}
	return
}

// GetNamespace get namespace object
func (fs *FileSystem) GetNamespace(ctx *serve.Context, name string, path string) *serve.Namespace {
	namespace := serve.NewNamespace(name, path, fs.getConfig(path), ctx.Server())
	return namespace
}

// GetApplication get application object
func (fs *FileSystem) GetApplication(ctx *serve.Context, name string, path string) *serve.Application {
	app := serve.NewApplication(name, path, fs.getConfig(path), ctx.Server())
	return app
}

// GetConfig get config
func (fs *FileSystem) GetConfig(path string) *metal.Metal {
	return fs.getConfig(path)
}

// ReadMetal read file as metal
func ReadMetal(path string) *metal.Metal {
	configFile := filepath.Join(path, "config.json")
	byt, err := ioutil.ReadFile(configFile)
	if err == nil {
		m := metal.NewMetal()
		m.Parse(byt)
		return m
	}
	return nil
}

// GetModule get module object
func (fs *FileSystem) GetModule(ctx *serve.Context, name string, path string) *serve.Module {
	module := serve.NewModule(name, path, fs.getConfig(path), ctx.Server())
	if fs.stat(filepath.Join(ctx.Server().Path(), module.Path, "app")) {
		module.AppEnabled = true
	}

	return module
}

//Stat for filesystem driver
func Stat(path string) bool {
	if f, _ := os.Stat(path); f != nil {
		return true
	}
	return false
}

// NewFileSystem object
func NewFileSystem(stat func(path string) bool, getConfig func(path string) *metal.Metal) *FileSystem {
	fs := new(FileSystem)
	fs.stat = stat
	fs.getConfig = getConfig
	return fs
}
