package driver_test

// func TestGetPathRootModule(t *testing.T) {
// 	fs := driver.NewFileSystem(func(path string) bool {
// 		if path == "/serve/modules/module" {
// 			return true
// 		}
// 		return false
// 	})
//
// 	server := serve.NewServer("", "/serve", fs)
// 	ns, nspath, app, apppath, module, modulepath, l := fs.GetPath(server, "/module")
//
// 	if !(module == "module" || modulepath == "/serve/module") {
// 		fmt.Println(ns, nspath, app, apppath, module, modulepath, l)
// 		t.Fail()
// 	}
// }
//
// func TestGetPathNamespaceModule(t *testing.T) {
// 	fs := driver.NewFileSystem(func(path string) bool {
// 		if path == "/serve/namespace" || path == "/serve/namespace/modules/module" {
// 			return true
// 		}
// 		return false
// 	})
//
// 	server := serve.NewServer("", "/serve", fs)
// 	ns, nspath, app, apppath, module, modulepath, l := fs.GetPath(server, "/namespace/module")
//
// 	if !(ns == "namespace" && nspath == "/serve/namespace" && module == "module" && modulepath == "/serve/namespace/modules/module") {
// 		fmt.Println(ns, nspath, app, apppath, module, modulepath, l)
// 		t.Fail()
// 	}
// }
//
// func TestGetPathAppModule(t *testing.T) {
// 	fs := driver.NewFileSystem(func(path string) bool {
// 		if path == "/serve/apps/app" || path == "/serve/modules/module" {
// 			return true
// 		}
// 		return false
// 	})
//
// 	server := serve.NewServer("", "/serve", fs)
// 	ns, nspath, app, apppath, module, modulepath, l := fs.GetPath(server, "/app/module")
//
// 	if !(app == "app" && apppath == "/serve/apps/app" && module == "module" && modulepath == "/serve/modules/module") {
// 		fmt.Println(ns, nspath, app, apppath, module, modulepath, l)
// 		t.Fail()
// 	}
// }
//
// func TestGetPathAppsModuleShouldFail(t *testing.T) {
// 	fs := driver.NewFileSystem(func(path string) bool {
// 		if path == "/serve/apps" || path == "/serve/modules/module" {
// 			return true
// 		}
// 		return false
// 	})
//
// 	server := serve.NewServer("", "/serve", fs)
// 	ns, nspath, app, apppath, module, modulepath, l := fs.GetPath(server, "/apps/module")
//
// 	if !(l == 0 && ns == "" && nspath == "" && app == "" && apppath == "" && module == "" && modulepath == "") {
// 		fmt.Println(ns, nspath, app, apppath, module, modulepath, l)
// 		t.Fail()
// 	}
// }
//
// func TestGetPathModulesModuleShouldFail(t *testing.T) {
// 	fs := driver.NewFileSystem(func(path string) bool {
// 		if path == "/serve/modules" || path == "/serve/modules/module" {
// 			return true
// 		}
// 		return false
// 	})
//
// 	server := serve.NewServer("", "/serve", fs)
// 	ns, nspath, app, apppath, module, modulepath, l := fs.GetPath(server, "/modules/module")
//
// 	if !(l == 0 && ns == "" && nspath == "" && app == "" && apppath == "" && module == "" && modulepath == "") {
// 		fmt.Println(ns, nspath, app, apppath, module, modulepath, l)
// 		t.Fail()
// 	}
// }
